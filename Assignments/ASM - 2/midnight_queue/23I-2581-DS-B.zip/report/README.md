# Editable report and figures

The main LaTeX file is [23I-2581-A2-DS-B.tex](../23I-2581-A2-DS-B.tex).
All image paths are relative to that file and point to [images/](./images/).
Each figure has a vector PDF for sharp typesetting and a high-resolution PNG
for convenient insertion elsewhere. SVG copies are in
[outputs/figures/](../outputs/figures/).

Compile from the project root with Tectonic:

    tectonic 23I-2581-A2-DS-B.tex

Alternatively, select **XeLaTeX** in Overleaf and upload the main TeX file
and this folder, preserving the directory structure. The source uses Arial
when installed, with TeX Gyre Heros as a portable fallback.

To reproduce all visuals, the executed notebook, the report and the ZIP from
the already-recorded measurements:

    python scripts/build_submission.py

This command needs the development dependencies and Tectonic or XeLaTeX.
It runs the tests, but does not repeat the expensive benchmark tournament.

The report has five pages, including the complete prediction-log appendix.
Part G is reserved for the demo and omitted from this report as requested.
