"use strict";
const el=id=>document.getElementById(id),fmt=n=>Number(n).toLocaleString("en-US");
const NS="http://www.w3.org/2000/svg",colors=["#a490ff","#90d3cb","#c7b581","#b79df4","#7ca9ad"];
let queue=[],page=0,runId=null,evidence=null,chartMode="flow",activity=[],latest=null;
const pageSize=50;
const digits={
 "0":["01110","11011","11011","11011","11011","11011","01110"],
 "1":["00100","01100","00100","00100","00100","00100","01110"],
 "2":["01110","10001","00001","00110","01000","10000","11111"],
 "3":["11110","00001","00001","01110","00001","00001","11110"],
 "4":["00010","00110","01010","10010","11111","00010","00010"],
 "5":["11111","10000","10000","11110","00001","00001","11110"],
 "6":["01110","10000","10000","11110","10001","10001","01110"],
 "7":["11111","00001","00010","00100","01000","01000","01000"],
 "8":["01110","10001","10001","01110","10001","10001","01110"],
 "9":["01110","10001","10001","01111","00001","00001","01110"],
 ",":["00000","00000","00000","00000","00000","00100","01000"],
 ".":["00000","00000","00000","00000","00000","00000","00100"],
 "—":["00000","00000","00000","11111","00000","00000","00000"]
};
function svgNode(tag,attrs={},parent){
 const node=document.createElementNS(NS,tag);for(const [name,value]of Object.entries(attrs))node.setAttribute(name,value);
 if(parent)parent.append(node);return node;
}
function text(parent,x,y,value,attrs={}){
 const node=svgNode("text",{x,y,fill:"#9598a6","font-size":11,"font-family":"Segoe UI,Arial,sans-serif",...attrs},parent);
 node.textContent=value;return node;
}
function dotNumber(id,value){
 const target=el(id),str=String(value);target.replaceChildren();target.setAttribute("aria-label",str);
 const svg=svgNode("svg",{viewBox:"0 0 "+(str.length*6*3.5)+" 26",preserveAspectRatio:"xMinYMid meet","aria-hidden":"true"},target);
 [...str].forEach((character,i)=>(digits[character]||digits["—"]).forEach((row,y)=>[...row].forEach((pixel,x)=>{
  if(pixel==="1")svgNode("circle",{cx:(i*6+x)*3.5+1.2,cy:y*3.5+1.2,r:1.04,fill:"currentColor"},svg);
 })));
 const accessible=document.createElement("span");accessible.className="sr-only";accessible.textContent=str;target.append(accessible);
}
function icon(name){
 const svg=svgNode("svg",{"aria-hidden":"true"});svgNode("use",{href:"#"+name},svg);return svg;
}
function setState(message,state="ready"){
 el("status").textContent=message;el("status").classList.toggle("error",state==="error");
 el("state-badge").replaceChildren(document.createElement("i"),document.createTextNode({ready:"Ready",working:"Working",verified:"Verified",cancelled:"Cancelled",error:"Needs attention"}[state]));
 el("state-badge").classList.toggle("error",state==="error");
 document.body.classList.toggle("busy",state==="working");
}
function logActivity(message){activity.unshift({message,time:new Date().toLocaleTimeString()});activity=activity.slice(0,20)}
function changeView(view){
 if(!["overview","queue","evidence"].includes(view))view="overview";
 el("workspace").dataset.view=view;el("evidence-panel").hidden=view!=="evidence";
 document.querySelectorAll("[data-view].nav-tab").forEach(button=>{button.classList.toggle("active",button.dataset.view===view);button.setAttribute("aria-pressed",String(button.dataset.view===view))});
 el("workspace-title").textContent={overview:"Transaction intelligence",queue:"Queue workspace",evidence:"Benchmark evidence"}[view];
}
function running(on){
 document.querySelectorAll("#settings select,#settings input").forEach(node=>node.disabled=on);
 el("run").disabled=on;el("cancel").disabled=!on;
}
function configurationChanged(){
 dotNumber("capacity",el("k").value||"—");
 el("input-context").textContent=fmt(el("n").value)+" records · "+el("condition").value;
 if(latest&&!runId)setState("Settings changed. Build a new queue to measure this selection.");
}
function resetResult(){
 queue=[];page=0;latest=null;el("search").value="";el("band-filter").value="";
 dotNumber("elapsed","—");dotNumber("comparisons","—");el("moves").textContent="—";el("size").textContent="0";
 el("export").disabled=true;el("verification").textContent="Not built";el("verification").className="tag";
 el("run-context").textContent="Preparing a fresh input for the selected algorithm";
 renderQueue();drawFlow();
}
function filteredQueue(){
 const search=el("search").value.trim().replaceAll(",",""),band=el("band-filter").value;
 return queue.filter(row=>(!search||String(row.txn_id).includes(search))&&(!band||row.band===Number(band)));
}
function renderQueue(){
 const filtered=filteredQueue(),total=Math.ceil(filtered.length/pageSize);
 page=Math.max(0,Math.min(page,total-1));const start=page*pageSize;el("rows").replaceChildren();
 if(!filtered.length){
  const row=el("rows").insertRow(),cell=row.insertCell();cell.colSpan=7;
  const empty=document.createElement("div");empty.className="empty";empty.append(icon(queue.length?"search":"layers"));
  const title=document.createElement("strong");title.textContent=queue.length?"No matching transactions":"Your next queue starts here";
  const note=document.createElement("span");note.textContent=queue.length?"Try another transaction ID or risk band.":"Choose an algorithm and K, then build the queue.";
  empty.append(title,note);cell.append(empty);
 }
 for(const row of filtered.slice(start,start+pageSize)){
  const tr=el("rows").insertRow();
  [fmt(row.rank),fmt(row.txn_id),"",row.amount.toFixed(2),fmt(row.time),row.risk.toFixed(4)].forEach(value=>tr.insertCell().textContent=value);
  const band=document.createElement("span");band.className="band"+(row.band<6?" low":"");band.textContent=row.band;tr.cells[2].append(band);
  const action=document.createElement("button");action.className="icon-button";action.type="button";action.title="Inspect transaction";
  action.setAttribute("aria-label","Inspect transaction "+row.txn_id);action.append(icon("search"));action.onclick=()=>showTransaction(row);
  tr.insertCell().append(action);
  tr.onmouseenter=()=>document.querySelectorAll("#flow-chart [data-rank]").forEach(path=>{path.style.opacity=Number(path.dataset.rank)===row.rank?"1":".12"});
  tr.onmouseleave=()=>document.querySelectorAll("#flow-chart [data-rank]").forEach(path=>path.style.opacity=".56");
 }
 el("range").textContent=filtered.length?fmt(start+1)+"–"+fmt(Math.min(start+pageSize,filtered.length))+" of "+fmt(filtered.length)+(filtered.length!==queue.length?" matches":" cases"):queue.length?"0 matches":"No queue built";
 el("page").textContent=(total?page+1:0)+" / "+total;
 el("previous").disabled=page===0;el("next").disabled=page+1>=total;
}
function drawLandscape(){
 const root=el("landscape-chart");root.replaceChildren();if(!evidence)return;
 const values=Array.from({length:10},(_,i)=>Math.log10(1+evidence.profile.band_counts[String(i)]));
 const max=Math.max(...values,1);
 function height(x){const p=x*9,j=Math.min(8,Math.floor(p));return (values[j]*(1-(p-j))+values[j+1]*(p-j))/max}
 function point(x,z){return [13+x*273+z*62,226-z*100-height(x)*94*Math.exp(-Math.pow((z-.5)*2.3,2))]}
 for(let j=0;j<=20;j++){
  const z=j/20,points=Array.from({length:91},(_,i)=>point(i/90,z));
  svgNode("polyline",{points:points.map(p=>p.join(",")).join(" "),fill:"none",stroke:"#9980fb","stroke-width":.7,opacity:.35+.35*(1-z)},root);
 }
 for(let i=0;i<=45;i++){
  const points=Array.from({length:21},(_,j)=>point(i/45,j/20));
  svgNode("polyline",{points:points.map(p=>p.join(",")).join(" "),fill:"none",stroke:"#9980fb","stroke-width":.65,opacity:.48},root);
 }
 text(root,15,233,"0",{"font-size":9});text(root,285,233,"9",{"font-size":9});text(root,136,233,"Risk band",{"font-size":9});
}
function drawProfile(root){
 if(!evidence){text(root,300,135,"Saved profile unavailable",{"text-anchor":"middle"});return}
 const p=evidence.profile,max=Math.max(...Object.values(p.band_counts));
 for(let band=9;band>=2;band--){
  const y=38+(9-band)*25,count=p.band_counts[String(band)],width=Math.log10(1+count)/Math.log10(1+max)*390;
  text(root,26,y+4,band,{"font-size":10});
  svgNode("line",{x1:54,y1:y,x2:54+width,y2:y,stroke:"#a490ff","stroke-width":2.4,opacity:.8},root);
  text(root,Math.min(550,66+width),y+4,fmt(count),{"font-size":10});
 }
 text(root,25,14,"Band",{"font-size":9});text(root,55,252,"Transaction count · logarithmic length",{"font-size":9});
}
function drawFlow(){
 const root=el("flow-chart");root.replaceChildren();
 if(!queue.length||chartMode==="profile"){
  drawProfile(root);el("flow-callout").hidden=false;el("flow-badge").textContent="Profile";
  el("flow-legend-high").textContent="Band counts";el("flow-legend-low").hidden=true;
  el("flow-description").textContent="Observed band volumes across the full file";
  el("flow-note").textContent=queue.length?"Full-file profile · saved counts":"Build a queue to trace individual records";
  root.setAttribute("aria-label","Observed full-file risk-band transaction counts");return;
 }
 el("flow-callout").hidden=true;el("flow-badge").textContent="Verified";
 el("flow-legend-high").textContent="Bands 6–9";el("flow-legend-low").hidden=false;
 el("flow-description").textContent="Band → Amount → Queue rank";
 el("flow-note").textContent="First "+Math.min(queue.length,50)+" of "+fmt(queue.length)+" queued records";
 root.setAttribute("aria-label","Actual ranking flow for the first fifty queued transactions");
 const sample=queue.slice(0,50),min=Math.min(...sample.map(row=>Math.log1p(row.amount))),max=Math.max(...sample.map(row=>Math.log1p(row.amount)));
 [45,300,555].forEach((x,i)=>{svgNode("line",{x1:x,y1:30,x2:x,y2:224,stroke:"#71727e","stroke-width":.6,opacity:.45},root);text(root,x,16,["Risk band","Amount · log scale","Queue rank"][i],{"text-anchor":"middle","font-size":10})});
 sample.forEach((row,i)=>{
  const y1=224-row.band/9*194,y2=224-(Math.log1p(row.amount)-min)/(max-min||1)*194,y3=32+i/Math.max(1,sample.length-1)*190;
  const color=row.band>=6?"#a490ff":"#90d3cb";
  const path=svgNode("path",{d:"M45 "+y1+" C140 "+y1+" 220 "+y2+" 300 "+y2+" S465 "+y3+" 555 "+y3,fill:"none",stroke:color,"stroke-width":.8,opacity:.56,"data-rank":row.rank},root);
  const title=svgNode("title",{},path);title.textContent="Rank "+row.rank+" · Transaction "+row.txn_id+" · Band "+row.band+" · Amount "+row.amount.toFixed(2);
  svgNode("circle",{cx:555,cy:y3,r:1.6,fill:color},root);
 });
 text(root,32,229,"0",{"font-size":9});text(root,32,36,"9",{"font-size":9});text(root,562,36,"1",{"font-size":9});text(root,562,226,String(sample.length),{"font-size":9});
}
function drawGauge(){
 const root=el("capture-gauge");root.replaceChildren();
 svgNode("path",{d:"M16 96 A74 74 0 0 1 164 96",fill:"none",stroke:"#282b31","stroke-width":15},root);
 svgNode("path",{d:"M16 96 A74 74 0 0 1 164 96",fill:"none",stroke:"#a490ff","stroke-width":15,"stroke-dasharray":"116.24 232.48"},root);
 svgNode("line",{x1:90,y1:12,x2:90,y2:30,stroke:"#eef0f2","stroke-width":1.6},root);
 text(root,90,79,"50%",{"font-size":26,fill:"#ece7ff","font-family":"Consolas,monospace","text-anchor":"middle"});
 text(root,90,100,"of fraud labels",{"font-size":8,"text-anchor":"middle"});
}
function renderEvidence(){
 const root=el("benchmark-chart");root.replaceChildren();el("benchmark-rows").replaceChildren();
 if(!evidence)return;
 const rows=evidence.tournament.filter(row=>row.n===Number(el("evidence-n").value)&&row.condition===el("evidence-condition").value);
 const finite=rows.filter(row=>row.seconds!==null),max=Math.max(...finite.map(row=>Math.log10(row.seconds)),0),min=Math.min(...finite.map(row=>Math.log10(row.seconds)),-3)-.2;
 rows.forEach((row,i)=>{
  const y=24+i*45,tr=el("benchmark-rows").insertRow();
  [row.algorithm,row.seconds===null?"DNF (>300 s)":row.seconds.toFixed(6)+" s",row.comparisons===null?"—":fmt(row.comparisons),row.moves===null?"—":fmt(row.moves)].forEach(value=>tr.insertCell().textContent=value);
  text(root,0,y+5,row.algorithm,{"font-size":12,fill:"#c5cbd0"});
  if(row.seconds!==null){
   const w=(Math.log10(row.seconds)-min)/(max-min)*540;
   svgNode("rect",{x:195,y:y-9,width:w,height:15,fill:colors[i%colors.length],opacity:.78},root);
   text(root,Math.min(820,205+w),y+3,row.seconds.toFixed(3)+" s",{"font-size":11});
  }else{text(root,195,y+4,"DNF · no invented time",{fill:"#bb9df4","font-size":11})}
 });
 text(root,195,265,"Algorithm time (s) · logarithmic bar length",{"font-size":10});
 el("evidence-note").textContent="Saved tournament measurements for "+el("evidence-condition").value+", n="+fmt(el("evidence-n").value)+". "+evidence.provenance+" DNF observations have no measured median. Concurrent tournament timings include host scheduling and cache contention."+(el("evidence-condition").value==="C6"?" C6 compares bands alone; the specification's tie-order conflict is disclosed in the report.":"");
}
function applyEvidence(){
 dotNumber("dataset-total",fmt(evidence.profile.rows));
 el("fraud-total").textContent=fmt(evidence.profile.fraud_count);
 el("populated-bands").textContent=Object.values(evidence.profile.band_counts).filter(Boolean).length+" populated bands";
 el("half-capacity").textContent=fmt(evidence.capture.k_half);
 el("capture-insight").textContent=fmt(evidence.capture.half_threshold)+" of "+fmt(evidence.capture.total_frauds)+" fraud labels. Capacity and ranking quality matter.";
 const recommendation=evidence.recommendations;
 el("batch-choice").textContent="Overnight batch: "+recommendation.batch;
 el("batch-insight").textContent="Lowest full-size worst median across C1–C5: "+recommendation.batch_seconds.toFixed(2)+" s. Already ranked input can reverse this choice.";
 el("heap-insight").textContent="Size-K Heap wins "+(recommendation.wins["Size-K Heap"]||0)+" of "+recommendation.comparison_cells+" measured cells; its worst slowdown is "+recommendation.regrets["Size-K Heap"].toFixed(2)+"×. Scores are assumed immutable.";
 const heap60=evidence.live.find(row=>row.width===3600&&row.strategy==="heap");
 const heap10=evidence.live.find(row=>row.width===600&&row.strategy==="heap");
 const timeLabel=row=>row?.seconds==null?"DNF":row.seconds.toFixed(3)+" s";
 el("live-insight").textContent="Saved full-file medians: "+timeLabel(heap60)+" for 60-minute windows; "+timeLabel(heap10)+" for 10-minute windows. Ordered publication is included.";
 drawLandscape();drawFlow();drawGauge();renderEvidence();
}
function showDialog(title,content){
 el("dialog-title").textContent=title;el("dialog-content").replaceChildren(content);
 if(!el("detail-dialog").open)el("detail-dialog").showModal();
}
function showTransaction(row){
 const list=document.createElement("dl");list.className="detail-list";
 for(const [label,value]of [["Queue rank",fmt(row.rank)],["Risk band",row.band],["Amount",row.amount.toFixed(2)],["Time from first record",fmt(row.time)+" s"],["Risk score",row.risk.toFixed(6)]]){
  const dt=document.createElement("dt"),dd=document.createElement("dd");dt.textContent=label;dd.textContent=value;list.append(dt,dd);
 }
 const box=document.createElement("div"),note=document.createElement("p");note.textContent="Within each risk band, Amount breaks the next tie. Time and transaction ID complete the order. Class is never part of the ranking.";
 box.append(list,note);showDialog("Transaction "+fmt(row.txn_id),box);
}
function showAbout(){
 const box=document.createElement("div");
 for(const value of ["The Midnight Queue · 23I-2581 · DS-B · Seed 232581.","Risk is the sum of squared population z-scores of V1–V28, computed over the full official file before sampling. The risk band is clipped floor(log₂ risk).","All seven choices use the project's custom algorithms. One comparison is one comparator call; one slot assignment is a move, and an actual swap counts as three.","Interactive results are single verified runs. Initial loading, scoring, construction and verification are outside the timer; producing the ordered output is included. A measured run above 300 seconds is DNF."]){
  const p=document.createElement("p");p.textContent=value;box.append(p);
 }
 showDialog("About the ranking engine",box);
}
el("settings").onsubmit=async event=>{
 event.preventDefault();if(runId!==null)return;resetResult();runId=crypto.randomUUID();
 running(true);const params={algorithm:el("algorithm").value,n:Number(el("n").value),condition:el("condition").value,k:Number(el("k").value),request_id:runId};
 setState("Building the queue… Preparing the official data and a fresh "+fmt(params.n)+"-record input.","working");
 logActivity("Started "+params.algorithm+" · "+params.condition+" · K="+fmt(params.k));
 try{
  const response=await fetch("/api/run",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify(params)});
  const data=await response.json();if(!response.ok)throw Error(data.error);
  latest=data;queue=data.queue.map((row,index)=>({...row,rank:index+1}));page=0;renderQueue();drawFlow();
  dotNumber("elapsed",data.elapsed_s.toFixed(4));dotNumber("comparisons",fmt(data.comparisons));el("moves").textContent=fmt(data.moves);
  el("size").textContent=fmt(data.queue_size);el("export").disabled=false;
  el("verification").textContent="Reference verified";el("verification").className="tag teal-tag";
  el("run-context").textContent=data.algorithm+" · "+data.condition+" · n="+fmt(data.n)+" · K="+fmt(data.k);
  setState("Verified against the reference. "+fmt(data.queue_size)+" cases from "+fmt(data.n)+" records; "+data.condition+", K="+fmt(data.k)+".","verified");
  logActivity("Verified "+data.algorithm+" · "+data.elapsed_s.toFixed(6)+" s · "+fmt(data.comparisons)+" comparisons");
 }catch(error){
  const cancelled=error.message.startsWith("Run cancelled");setState(error.message,cancelled?"cancelled":"error");
  el("run-context").textContent=cancelled?"Run cancelled · no timing result recorded":"No verified queue produced";
  logActivity(error.message);
 }finally{runId=null;running(false)}
};
el("cancel").onclick=async()=>{
 if(!runId)return;el("cancel").disabled=true;setState("Cancelling the active worker…","working");
 try{const response=await fetch("/api/cancel",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({request_id:runId})});if(!response.ok)throw Error("Cancellation request failed")}
 catch(error){if(runId)el("cancel").disabled=false;setState(error.message,"error")}
};
el("n").onchange=()=>{el("k").max=el("n").value;el("k").value=Math.min(Number(el("k").value),Number(el("n").value));configurationChanged()};
el("k").oninput=configurationChanged;el("algorithm").onchange=configurationChanged;el("condition").onchange=configurationChanged;
el("previous").onclick=()=>{page--;renderQueue()};el("next").onclick=()=>{page++;renderQueue()};
el("search").oninput=()=>{page=0;renderQueue()};el("band-filter").onchange=()=>{page=0;renderQueue()};
document.querySelectorAll(".nav-tab").forEach(button=>button.onclick=()=>changeView(button.dataset.view));
document.querySelector(".brand").onclick=event=>{event.preventDefault();changeView("overview")};
el("configure").onclick=()=>{changeView("queue");el("queue-panel").scrollIntoView({block:"start"});el("algorithm").focus()};
el("focus-search").onclick=()=>{changeView("queue");el("search").focus()};
el("open-evidence").onclick=()=>changeView("evidence");
el("evidence-n").onchange=renderEvidence;el("evidence-condition").onchange=renderEvidence;
el("flow-mode").onclick=()=>{chartMode="flow";el("flow-mode").classList.add("selected");el("profile-mode").classList.remove("selected");el("flow-mode").setAttribute("aria-pressed","true");el("profile-mode").setAttribute("aria-pressed","false");drawFlow()};
el("profile-mode").onclick=()=>{chartMode="profile";el("profile-mode").classList.add("selected");el("flow-mode").classList.remove("selected");el("profile-mode").setAttribute("aria-pressed","true");el("flow-mode").setAttribute("aria-pressed","false");drawFlow()};
el("about-button").onclick=showAbout;el("dataset-info").onclick=showAbout;el("close-dialog").onclick=()=>el("detail-dialog").close();
el("history-button").onclick=()=>{
 const list=document.createElement("ul");list.className="activity-list";
 for(const event of activity){const li=document.createElement("li"),time=document.createElement("time");time.textContent=event.time;li.append(time,document.createTextNode(event.message));list.append(li)}
 if(!activity.length){const li=document.createElement("li");li.textContent="No runs in this browser session. Build a queue to start.";list.append(li)}
 showDialog("Run activity · this session",list);
};
el("export").onclick=()=>{
 if(!queue.length)return;
 const csv=["Rank,Transaction ID,Risk band,Amount,Time (s),Risk score",...queue.map(row=>[row.rank,row.txn_id,row.band,row.amount,row.time,row.risk].join(","))].join("\r\n");
 const url=URL.createObjectURL(new Blob([csv],{type:"text/csv;charset=utf-8"})),link=document.createElement("a");
 link.href=url;link.download="midnight_queue_K"+queue.length+".csv";link.click();setTimeout(()=>URL.revokeObjectURL(url),1000);
 logActivity("Exported "+fmt(queue.length)+" verified queue records");
};
dotNumber("capacity","52");dotNumber("elapsed","—");dotNumber("comparisons","—");dotNumber("dataset-total","—");drawGauge();
(async()=>{
 try{
  const response=await fetch("/api/config");if(!response.ok)throw Error("Console configuration could not load");
  const config=await response.json();for(const name of config.algorithms){const option=document.createElement("option");option.value=option.textContent=name;el("algorithm").append(option)}
  el("algorithm").value="Size-K Heap";el("run").disabled=false;setState("Ready. Choose an algorithm and K to inspect its ordered queue.");
 }catch(error){setState(error.message,"error")}
 try{
  const response=await fetch("/api/evidence");if(!response.ok)throw Error("Saved benchmark evidence is unavailable.");
  evidence=await response.json();applyEvidence();
 }catch(error){
  el("populated-bands").textContent="Profile unavailable";el("batch-insight").textContent=error.message;
  el("heap-insight").textContent="Interactive queue measurements remain available.";el("evidence-note").textContent=error.message;drawFlow();
 }
})();
